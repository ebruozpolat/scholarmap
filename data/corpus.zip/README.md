# Network Neuroscience Citation Corpus
## Generated: 2026-06-20

### Contents
- **graph.json**: Full citation graph with 210 papers and 700 edges
- **papers/**: Individual paper files with full metadata

### Data Statistics
- Total papers: 210
- Total citation edges: 700
- Communities detected: 6
- Papers with abstracts: 210/210 (100%)
- Papers with DOI/URL: 210/210 (100%)
- Papers with citation counts: 182/210 (87%)
- Total citation count: 311,259

### Edge Construction Methods
1. Co-author relationships (papers sharing first author)
2. TF-IDF abstract similarity (>0.15 threshold)
3. Title similarity (>0.2 threshold)
4. Year proximity (within 2 years)

### Communities
- Connectome Mapping: 25 papers
- Functional Connectivity & fMRI: 50 papers
- Graph Theory & Network Analysis: 86 papers
- Brain Network Dynamics: 35 papers
- Structural Connectivity & DTI: 9 papers
- Network Models: 5 papers

### Sources
- arXiv preprints
- Google Scholar
- Web research (Semantic Scholar, PubMed)

### License
Data compiled from publicly available academic sources.
